import {action, observable} from "mobx";
import {API_URL} from "../constants";

export class Store {
    @observable posts = [];
    @observable loading = false;

    @action
    fetchPosts = () => {
        this.loading = true;
        return fetch(API_URL)
            .then(resp => resp.json())
            .then(data => this.posts = data.pageItems)
            .catch(e => console.error(e))
            .finally(() => this.loading = false);
    }
}

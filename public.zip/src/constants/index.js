export const API_URL = "https://raw.githubusercontent.com/traa/apiplp/master/db.json";
export const HEADER_TABLE = ['image','title','price'];
